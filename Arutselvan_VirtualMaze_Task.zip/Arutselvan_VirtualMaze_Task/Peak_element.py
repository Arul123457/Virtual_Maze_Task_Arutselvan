# 1) Given an array of integers, find a peak element. A peak element is an element that is greater than its neighbors.
# Example:
# For the array [1, 2, 3, 1], the peak element is 3 because 3 is greater than its neighbors 2 and 1.

def PeakElement(nums):
    length_num = len(nums)
    left, right=0, length_num - 1
    while left < right:
        mid=(left + right) // 2
        if nums[mid] > nums[mid + 1]:
            right = mid
        else:
            left=mid + 1
    return left
arr =list(map(int,input().split(',')))
peak_index = PeakElement(arr)
print(f"The peak element is {arr[peak_index]} at index {peak_index}.")
