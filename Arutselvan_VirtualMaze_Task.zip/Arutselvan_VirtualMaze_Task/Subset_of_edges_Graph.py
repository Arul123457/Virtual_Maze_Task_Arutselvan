# 3) Given a connected, undirected graph, find a subset of the edges that connects all the vertices together 
# without any cycles and with the minimum possible total edge weight.
# input
# graph = [ [0, 2, 0, 6, 0], [2, 0, 3, 8, 5], [0, 3, 0, 0, 7], [6, 8, 0, 0, 9], [0, 5, 7, 9, 0] ]
# Output = 16

import sys

def minKey(key, mstSet, V):
    min=sys.maxsize
    min_index=-1
    for v in range(V):
        if key[v] < min and not mstSet[v]:
            min=key[v]
            min_index=v
    return min_index
def primMST(graph):
    V=len(graph)
    key=[sys.maxsize] * V  
    parent=[None] * V  
    key[0]=0  
    mstSet=[False] * V  
    parent[0]=-1  
    for _ in range(V):
        u=minKey(key, mstSet, V)
        mstSet[u]=True
        for v in range(V):
            if graph[u][v] > 0 and not mstSet[v] and key[v] > graph[u][v]:
                key[v]=graph[u][v]
                parent[v]=u
    total_weight=0
    for i in range(1, V):
        total_weight += graph[i][parent[i]]
    return total_weight
graph = [
    [0, 2, 0, 6, 0],
    [2, 0, 3, 8, 5],
    [0, 3, 0, 0, 7],
    [6, 8, 0, 0, 9],
    [0, 5, 7, 9, 0]
]
output=primMST(graph)
print(f"The minimum total weight of the MST is {output}.")
